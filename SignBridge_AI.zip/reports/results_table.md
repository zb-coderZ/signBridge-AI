| Model | Accuracy | Macro-F1 | Inference ms/image |
|---|---:|---:|---:|
| CNN | 0.7054 | 0.7072 | 0.350 |
| Random Forest | 0.8123 | 0.7961 | 0.042 |
