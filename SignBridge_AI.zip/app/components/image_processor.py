"""WebRTC processor for image-model webcam recognition."""
from __future__ import annotations

import av
from streamlit_webrtc import VideoProcessorBase

from core.image_engine import ImageRecognitionEngine


class ImageVideoProcessor(VideoProcessorBase):
    """Run the image preprocessing and CNN on each webcam frame."""

    def __init__(self, engine: ImageRecognitionEngine | None = None) -> None:
        self.engine = engine

    def recv(self, frame: av.VideoFrame) -> av.VideoFrame:
        image = frame.to_ndarray(format="bgr24")
        if self.engine is not None:
            result = self.engine.process(image)
            if result.prepared is not None:
                x1, y1, x2, y2 = result.prepared.bbox
                import cv2
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 220, 120), 2)
        return av.VideoFrame.from_ndarray(image, format="bgr24")
